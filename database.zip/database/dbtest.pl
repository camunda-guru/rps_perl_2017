use DBI;
use DBD::mysql

# HTTP HEADER
#print "Content-type: text/html \n\n";

# CONFIG VARIABLES
#$platform = "mysql";
$database = "nessu";
#$host = "localhost";
#$port = "3306";
#$tablename = "article";
$user = "root";
$pw = "vignesh";

#DATA SOURCE NAME
$dsn = "dbi:mysql:$database:localhost:3306";

# PERL DBI CONNECT
$DBIconnect = DBI->connect($dsn, $user, $pw);


$sth = $DBIconnect->prepare("select * from article");
$sth->execute();
while ( @row = $sth->fetchrow_array )
{
	print "@row\n";
}
sleep(10);