use DBI;
use DBD::mysql;
# CONFIG VARIABLES
#$platform = "mysql";
$database = "LTDB";
$host = "localhost";
$port = "3306";
#$tablename = "UNIT_TEST";
$user = "root";
$pw = "vignesh";

#DATA SOURCE NAME
$dsn = "dbi:mysql:$database:$host:$port";

# PERL DBI CONNECT
$DBIconnect = DBI->connect($dsn, $user, $pw);
$sth = $DBIconnect->prepare("select * from UNIT_TEST");
$sth->execute();

while ( @row = $sth->fetchrow_array )
{
	print "@row\n";
}
sleep(5);

print "Enter TEST CASE NO\t";

$TNO = <STDIN>;
my $sth = $DBIconnect->prepare("SELECT TC_NO,TC_NAME
                        FROM UNIT_TEST
                        WHERE TC_NO = ?");
$sth->execute( chomp($TNO) ) or die $DBI::errstr;
print "Number of rows found :" , $sth->rows,"\n";
while (my @row = $sth->fetchrow_array()) {
   my ($TC_NO, $TC_NAME ) = @row;
   print "TC NO = $TC_NO, TC NAME = $TC_NAME\n";
}
$sth->finish();