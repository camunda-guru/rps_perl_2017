use strict;
use warnings;
use v5.10; # for say() function
 
use DBI;
 
# MySQL database configurations
my $dsn = "DBI:mysql:perlmysqldb";
my $username = "root";
my $password = '';
 
say "Perl MySQL Update Data Demo";
 
# connect to MySQL database
my %attr = ( PrintError=>0, RaiseError=>1);
 
my $dbh = DBI->connect($dsn,$username,$password, \%attr);
 
# update statement
my $sql = "UPDATE links
           SET title = ?,
               url = ?, 
               target = ?
    WHERE id = ?";
 
my $sth = $dbh->prepare($sql);
 
my $id = 2;
my $title = "Perl MySQL Update Data Tutorial";
my $url = "http://www.mysqltutorial.org/perl-mysql/perl-mysql-update/";
my $target = "_self";
 
# bind the corresponding parameter
$sth->bind_param(1,$title);
$sth->bind_param(2,$url);
$sth->bind_param(3,$target);
$sth->bind_param(4,$id);
 
# execute the query
$sth->execute();
 
say "The record has been updated successfully!";
 
$sth->finish();
 
# disconnect from the MySQL database
$dbh->disconnect();