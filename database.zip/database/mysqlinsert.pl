use DBI;
use DBD::mysql;
 
# CONFIG VARIABLES
#$platform = "mysql";
$database = "LTDB";
$host = "localhost";
$port = "3306";
#$tablename = "UNIT_TEST";
$user = "root";
$pw = "vignesh";

#DATA SOURCE NAME
$dsn = "dbi:mysql:$database:$host:$port"; 

 
print "Perl MySQL INSERT Demo";
 
# get user's input links
my @reqmts = get_reqmts();
 
# connect to MySQL database
my %attr = (PrintError=>0,RaiseError=>1 );
my $dbh = DBI->connect($dsn,$user,$pw,\%attr);
 
# insert data into the links table
my $sql = "INSERT INTO Project_Req(REQ_NO,FEATURE,STATUS)
    VALUES(?,?,?)";
 
my $stmt = $dbh->prepare($sql);
 
# execute the query
foreach my $reqmt(@reqmts){
  if($stmt->execute($reqmt->{REQNO}, $reqmt->{FEATURE}, $reqmt->{STATUS})){
    print "reqmt $reqmt->{REQNO} inserted successfully";
  }
 
}
$stmt->finish();
 
# disconnect from the MySQL database
$dbh->disconnect();
 
sub get_reqmts{
   my $cmd = '';
   my @reqmts;
   # get links from the command line
   my($REQ_NO,$FEATURE,$STATUS);
 
   # repeatedly ask for link data from command line
   do{
     print "REQ_NO:";
     chomp($REQ_NO = <STDIN>); 
 
     print "FEATURE:";
     chomp($FEATURE = <STDIN>);
 
     print "STATUS:";
     chomp($STATUS = <STDIN>);
 
     #
     my %reqmt = (REQNO=> $REQ_NO, FEATURE=> $FEATURE, STATUS=> $STATUS);
 
     push(@reqmts,\%reqmt);
 
     print("\nDo you want to insert another link? (Y/N)?");
     chomp($cmd = <STDIN>);
     $cmd = uc($cmd);
   }until($cmd eq 'N');
 
   return @reqmts;
}