$name="";
print "OK \n" if defined $name;