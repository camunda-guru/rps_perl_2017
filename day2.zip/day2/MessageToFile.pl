print "Enter File Name\t";
$filename=<STDIN>;
chomp $filename;
$filename=$filename.".txt";
print $filename;
$file="F:\\Polarisdocuments\\".$filename;
open(INFO,">$file");
$message=getc(STDIN);
while($message ne "\n")
{
	print INFO $message;
	$message=getc(STDIN);
}

close(INFO);