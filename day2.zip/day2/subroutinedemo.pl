sub greetme 
{ 
	print "Welcome Venkatesh, how are you!\n";
}

&greetme123 if defined &greetme123;

print "Program continues....\n";

&greetme;  # Call to subroutine

print "More program here.\n";

&bye;

sub bye { print "Bye, adjo, adieu.\n"; }
&bye;