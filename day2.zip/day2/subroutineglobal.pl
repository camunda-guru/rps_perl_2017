#Subroutine definition
sub bye { 
	print "Bye $name\n"; $name="Tom";
}  
 
$name="Eniyan";
print "Hello to you!\n";
&bye;
print "Out of the subroutine. Hello $name.\n";  # $name is now Tom
                          
&bye;
