$a=3.15;
{
local $a=3; #modifies existing value
print $a,"\n";
print $::a,"\n";
}
print $a,"\n";
print $::a,"\n";

{
my $a=3; #creates new variable
print $a,"\n";
print $::a,"\n";
}
print $a,"\n";
print $::a,"\n";