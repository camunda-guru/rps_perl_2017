use Time::Piece;
require '../day1/AgeModule.pl';
no warnings;
print "Enter Birth Date\t";
$birthdate=<STDIN>;

chomp $birthdate;

$format = '%d/%m/%Y';
$dt1 = Time::Piece->strptime($birthdate, $format);
#chomp $dt1;
#print $dt1;


#$currdate=`date /T`;
$currdate=localtime->strftime('%d/%m/%Y');
chomp $dt2;
#print($currdate);
$dt2 = Time::Piece->strptime($currdate, $format);

#print $dt2;

polarispack::agecal($dt1,$dt2);
#printf ("The date is %s",$currdate);