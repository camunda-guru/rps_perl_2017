#scalar to array
$value="NS:IE:MOSAIC";
@browser=split(/:/,$value);
print @browser;