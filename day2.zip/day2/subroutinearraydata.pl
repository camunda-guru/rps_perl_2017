print "What is your full name? ";
chomp($fullname=<STDIN>);
&title($fullname); # Context is array
#print "Welcome $arrayname[0]!\n";

#
#print "What is the name of that book you are reading? ";
#chomp($bookname=<STDIN>);
#$scalarname = title($bookname);  # Context is string
#print "The book $arrayname[0] is reading is $scalarname.\n";
 
sub title{
 # Function to capitalize the first character of each word
 # in a name and to return a string or an array of words
# print("\n received data",@_);

print(@_);
 $text=shift;
 #print($text);
#my $newstring;
 #my$text=lc($text);
 @newtext=split(" ", $text); # Create a list of words
 #print(@newtext);
 foreach  $word (@newtext){
 	  #print("Received Data","\t",$word);
     $word = ucfirst($word); # Capitalize the first letter
     #print($word);
      #$newstring .= "$word "; # Create a title string
}          
#     @newarray = split(" ", $newstring);
#     # Split the string into an array
#    chop($newstring); # Remove trailing white space
#
#return wantarray ? @newarray : $newstring;  # Return either array
## or scalar based on how the subroutine was called

}

