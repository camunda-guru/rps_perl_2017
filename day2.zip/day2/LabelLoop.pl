# Program that uses a label without a loop and the redo statement
REATTEMPT: {
 print "Are you shifting to reattempt? ";
chomp($answer = <STDIN>);
 unless ($answer eq "OK"){goto ATTEMPT ;}
}


ATTEMPT: {
 print "Are you confident? ";
chomp($answer = <STDIN>);
 unless ($answer eq "yes"){goto REATTEMPT ;}
}

RedoATTEMPT: {
 print "do you recycle? ";
chomp($answer = <STDIN>);
 unless ($answer eq "yes"){redo RedoEATTEMPT ;}
}
