use strict;
use warnings;
use 5.010;
 
sub hi {
    return "main";
}
 
package networking;
 
sub hi {
    return "socket number";
}
 
say main::hi();   # main
say networking::hi();    # networking
say hi();         # networking
 
package main;
 
say main::hi();   # main
say networking::hi();    # networking
say hi();         # main