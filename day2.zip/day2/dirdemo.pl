open(LISTDIR, 'dir "C:\perl" |') || die;
@filelist = <LISTDIR>;
foreach  $file ( @filelist ){
	print $file;
}
