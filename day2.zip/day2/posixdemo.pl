use POSIX();
$x=10;
$exponent=2;
$ret = POSIX::pow($x,$exponent);
print ($ret,"\n");
print(POSIX::round(5.18));
#generating the data

@machineIds=();

for($i=0;$i<10;$i++)
{
	#$machineIds[$i]=int(rand(1000));
	$machineIds[$i]=POSIX::round(rand(1000))
}

print("\nPrinting random data...");
foreach $element(@machineIds)
{
	print($element,"\t");
}

use Time::Piece;

my $date = localtime->strftime('%m/%d/%Y');
print "\n",$date;