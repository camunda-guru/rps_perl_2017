# Passing by reference with pointers
@list1= (1..10);
@list2 = (5..20);

#display(@list1, @list2); # Pass two arrays


display(\@list1, \@list2); # Pass two pointers  

sub display{
  print "@_\n"; #keep this for futher explore
 
}