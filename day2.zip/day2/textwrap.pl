use Text::Wrap;
$Text::Wrap::columns = 25;
$indent_first ="-";
$indent_subsq = ": ";
$text = "For the life of me  I could never understand  why Mr Perkins didn't enjoy his job.  He had everything a man could want:  a place on the board,  an absent boss and a cat named Henry.";
print wrap($indent_first, $indent_subsq, $text);
