#array to scalar
@browser=("IE","NS","MOSAIC");
print $browser[1];
$value=join("->",@browser);
print "\n",$value;
# Joining each element of a list with a newline
@names=('Dan','Dee','Scotty','Liz','Tom');
@names=join("\n", sort(@names));
print "\n",@names,"\n";