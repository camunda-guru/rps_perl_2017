foreach $key (keys(%ENV)){
print "$key\t";
print ($ENV{$key},"\n");
}
print "\nYour login name $ENV{'USERNAME'}\n";
$pwd=$ENV{'USERPROFILE'};
print "\n", $pwd, "\n";
