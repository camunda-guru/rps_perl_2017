$a=56,$b=90;
$expr = '$a + $b';
print(eval $expr); # 1 evaluates
print(eval "$expr"); # 2 evaulates
print(eval '$expr'); # 3 treats as string

#trapping error
use strict;
use warnings;

# Create a string containing Perl code.
my $code = q|
    my $text = "Hello";
    
    print "$text\n";
    
    # Deliberately introduce an error as bareword.
    jljlk
|;

my $result = eval($code);

# If there's a problem eval'ing the
# code, eval() returns undef and
# the error is found in $@.
unless($result) {
    print $@;
}



$result = eval { 
    my $wrong = 5/0;
    
    print "Value: $wrong";
};

print "Script is still running!\n";

unless($result) {
    print $@;
}
