use strict;
use warnings;
use Term::ReadKey;

ReadMode 4;    # Turn off controls keys
my $key;

while ( !defined( $key = ReadKey(-1) ) ) {
    print "No key yet\n";
    sleep 5;
}
print "Get key $key\n";