# This script copies one binary file to another. 
# Note its use of binmode to set the mode of the filehandle.

$infile="C:\\Users\\BALASUBRAMANIAM\\Pictures\\admk.jpg";
open( INFILE, "<$infile" );
open( OUTFILE, ">polaris.jpg" );

binmode( INFILE );     # Crucial for binary files!

binmode( OUTFILE ); 
# binmode should be called after open() but before any I/O 
# is done on the filehandle.
#seek(INFILE,30,0);
while ( read( INFILE, $buffer, 1024) ) {
	 print OUTFILE $buffer;
}
    
close( INFILE ); 
close( OUTFILE );

