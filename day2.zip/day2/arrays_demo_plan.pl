@names=qw/Janak Junoon Jake/;
print @names, "\n"; # prints without the separator
#delete
delete $names[2];
print @names, "\n"; # prints without the separator

@names = qw(Janak Junoon Jake);
print "Hi $names[1]\n", if exists $names[1];
print "Out of range!\n", if not exists $names[5];

@browser = ("IE","OPERA");
unshift(@browser,"Mosaic");
unshift(@browser,"Safari");#add from front
print @browser, "\n";
for($i=0;$i<3;$i++)
{
shift(@browser);#remove from front
}
print @browser,"\n";
push(@browser,"netscape");#add from end
print @browser,"\n";
$value=pop(@browser);#remove from end
print $value,"\n";

# Array slices
@names=('Tamil', 'Dinesh', 'Harry', 'Patrick' );
@pal=@names[2..3]; # slice -- @names[1..3] also O.K.
print "@pal\n\n";
($friend[0], $friend[1], $friend[2])=@names; # Array slice
print "@friend\n";