# Program to call a subroutine without defining it
sub AUTOLOAD {
	
        print "Missing Subroutines\t";
        print "call when sub is missing $AUTOLOAD\n";
	#return $subname;   
}

    

 &greet();
 &cal(3,2007);   