no warnings;

use POSIX();
@arr=(1..10);
sub printIds
{
  print("\nPrinting from main package....");	
   foreach $i(@arr)
   {
   	 print(rand(1000));
   }
	 
}


package lanT;

sub printDate
{
   
	print("Current Date=",`date /T`);
}
package cgi;
use POSIX();
@arr=(1..10);
sub printIds
{
	 print("\nPrinting from CGI package....");	
   foreach $i(@arr)
   {
   	 print(rand(1000));
   }
	 
}
package hcl;
use POSIX();
@arr=(1..10);
sub printIds
{
  print("\nPrinting from HCL package....");	
   foreach $i(@arr)
   {
   	 print(rand(1000));
   }
	 
}
package main;

lanT::printDate();
printIds();
main::printIds();