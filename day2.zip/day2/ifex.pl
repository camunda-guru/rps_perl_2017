print "How old are you? ";
chomp($age = <STDIN>);
if ($age >= 21 ){ # If true, enter the block
 print "Let's party!\n";
}
 print "You said you were $age.\n";

print "What version of the operating system are you using? ";
chomp($os=<STDIN>);
if ($os > 2.2) {print "Most of the bugs have been worked
out!\n";}
 else {print "Expect some problems.\n";}
print(localtime[0],"->",localtime[1],"-->",localtime[2]); 
#base year 1900
#$sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst
$hour=(localtime)[2];
$currentYear=(localtime)[5]+1900;
print("\nyear","->",$currentYear);
$currentMonth=(localtime)[4]+1;
print("\nmonth","->",$currentMonth);
$currentDay=(localtime)[3];
print("\nday","->",$currentDay);
$currentDate=$currentDay."/".$currentMonth."/".$currentYear;
print("\nDate","-->",$currentDate);

if ($hour >= 0 && $hour < 12){print "Good�morning!\n";}
elsif ($hour == 12){print "Lunch time.\n";}
elsif ($hour > 12 && $hour < 17) {print "Siesta time.\n";}
 else {print "Goodnight. Sweet dreams.\n";}