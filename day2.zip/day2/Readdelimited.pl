open(INFO,'F:\Polarisdocuments\sample.txt') or die('File not existing');

$line=<INFO>;
while($line)
{
@data=split(/--/,$line);

print ($data[0],"\t");
print ($data[1],"\n");
$line=<INFO>;
}
close(INFO); 