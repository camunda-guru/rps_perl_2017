sub convertnames
{
	print(@_);
	$size=@_;
	print($size);
	$text=shift;
	@nameArray=split(" ",$text);
	$size=@nameArray;
	print($size);
	$newName="";
	foreach $word(@nameArray)
	{
		$newName = $newName.(ucfirst($word));
	}
	return $newName;
}

print qq(\nEnter the name);
$name=<STDIN>;
chomp($name);
$result=convertnames($name);
print($result);