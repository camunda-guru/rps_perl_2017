use strict;
use warnings;

use autodie;
use IO::File;

my $filename_to_read = 'dbiinperl.txt';
# Put the file name in a string variable
# so we can use it both to open the file
# and to refer to in an error message
# if needed.


# Use the open() function to open the file.
unless(open FILE, $filename_to_read) {
    # Die with error message 
    # if we can't open it.
    die "\nUnable to open $filename_to_read\n";
}

open my $fh, '<', $filename_to_read;
while (my $line = <$fh>)
{
    chomp($line);

    # Do something with $line.
    print($line);
}
close($fh);

# a "perl file copy" example
use File::Copy;

# somewhere later in the code ...
my $original_file = 'dbiinperl.txt';
my $new_file = 'dest-filename.txt';

# do the perl file copy here:
copy($original_file, $new_file) or die "The copy operation failed: $!";
