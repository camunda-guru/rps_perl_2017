$first="Charles";
$last="Dobbins";
&greeting ( $first, $last );    
sub greeting{
	print "@_", "\n";   
	print "Welcome to the club, $_[0] $_[1]!\n"; 
}


# Program to demonstrate how @_ references values.
sub params{
	print 'The values in the @_ array are ', "@_\n";
	print "The first value is $_[0]\n";
	print "The last value is ", pop(@_),"\n";
        #@array=@_; 
	foreach  $value ( @_ ) {
		$value+=5;
		print "The value is $value", "\n";
	}
}

print "Give me 5 numbers : ";
@n=split(':',<STDIN>);
&params(@n); 
print "Back in main\n";
print "The new values are @n \n";

sub MAX { 
	my($max) = shift(@_);
	foreach $foo ( @_ ){
		$max = $foo if $max < $foo;
		print $max,"\n";
	}
	print "------------------------------\n";
	$max;
}
sub MIN {
	my($min) = pop( @_ );
	foreach $foo ( @_ ) {
		$min = $foo if $min > $foo;
		print $min,"\n";
	}
	print "------------------------------\n";
	return $min;
}

my $biggest = &MAX ( 2, 3, 4, 10, 100, 1 );
my $smallest= &MIN ( 200, 2, 12, 40, 2, 20 );
print "The biggest is $biggest and the smallest is $smallest.\n"; 

# Passing by reference with pointers
@list1= (1..100);
@list2 = (5..200);

display(@list1, @list2); # Pass two arrays

print "-" x 35,"\n";

display(\@list1, \@list2); # Pass two pointers  

sub display{
  print "@_\n";
}


print "What is your full name? ";
chomp($fullname=<STDIN>);

@arrayname = title($fullname); # Context is array
print "Welcome $arrayname[0]!\n";


print "What is the name of that book you are reading? ";
chomp($bookname=<STDIN>);
$scalarname = title($bookname);  # Context is string
print "The book $arrayname[0] is reading is $scalarname.\n";
 
sub title{
 # Function to capitalize the first character of each word
 # in a name and to return a string or an array of words
 my $text=shift;
my $newstring;
 #my$text=lc($text);
 my @newtext=split(" ", $text); # Create a list of words
 foreach my $word ( @newtext ){
     $word = ucfirst($word); # Capitalize the first letter
   $newstring .= "$word "; # Create a title string
}          
     @newarray = split(" ", $newstring);
     # Split the string into an array
    chop($newstring); # Remove trailing white space

return wantarray ? @newarray : $newstring;  # Return either array
# or scalar based on how the subroutine was called

}

