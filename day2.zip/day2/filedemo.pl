use strict;
use warnings;

use Path::Tiny;
use autodie; # die if problem reading or writing a file

my $dir = path("./logs"); # /tmp

my $file = $dir->child("code_log.txt"); # /tmp/file.txt
print($file);
 
  if (-f $file) {
    print "File Exists!";
  } else {
    print "File does not exist";
  }

mkdir $dir unless -d $dir; # Check if dir exists. If not create it.
open my $fileHandle, ">>", "$file" or die "Can't open '$file'\n";
  print "file open!\n";
 

my @list = ('HCL', 'IBM', 'CGI', 'CTS');

foreach my $line ( @list ) {
    # Add the line to the file
    $fileHandle->print("\n");
    $fileHandle->print($line);
}
close($fileHandle );


# Read in line at a time
open  $fileHandle, "<", "$file" or die "Can't open '$file'\n";
while( my $line =  $fileHandle->getline() ) {
        print $line;
}
close($fileHandle);