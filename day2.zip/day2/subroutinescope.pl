#  The scope of my variables     
my $name = "Rani";


print "$name\n";
	{  # Enter block
		print "My name is $name\n";
		my $name = "Eniyan";
		print "Now name is $name\n";
		my $son = "Kumar";
		print "My son is $son.\n";
	}  # Exit block
print "$name is back.\n";
print "I can't see my son name,$son, out here.\n";