package Employee;
use Person;
use strict;
our @ISA = qw(Person); 
