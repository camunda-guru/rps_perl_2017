package Person;
sub new
{
	my $class=shift;
	my $self={
		firstname=>shift,
		lastname=>shift,
	};
	bless $self,$class;
	
	
}

#accessor method for Person first name
sub firstName {
    my ( $self, $firstName ) = @_;
    $self->{firstname} = $firstName if defined($firstName);
    return $self->{firstname};
}

#accessor method for Person first name
sub lastName {
    my ( $self, $lastName ) = @_;
    $self->{lastname} = $lastName if defined($lastName);
    return $self->{lastname};
}


sub print {
    my ($self) = @_;

    # Print all the values just for clarification.
    print "First Name is $self->{firstname}\n";
    print "Last Name is $self->{lastname}\n";
}

return 1;
