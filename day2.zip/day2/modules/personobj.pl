use Person;
#use Employee;
my $personobj=new Person("Polaris","consulting");
$personobj->print();
#print $personobj->firstName("Virtusa");
#print $personobj->lastName("Technolgy");
=forcomment
$object = new Employee( "Shaji", "Singh", 23234345);
# Get first name which is set using constructor.
print $object->firstName();
=cut

