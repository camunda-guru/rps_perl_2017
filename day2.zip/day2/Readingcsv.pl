open(FH,'F:\LandTPerl\AnnualSheet.csv')or die('File not found');

$line=<FH>;

while($line)
{
	@data=split(/,/,$line);
	#$size=@data;
	#print($size);
	foreach $col(@data)
	{
		print $col,"\t";
	}
	
	$line=<FH>;
	
}


close(FH);
