use strict;
use warnings;
use 5.24.2;
no warnings 'experimental';
#print vs say  
say "Welcome to DLF!!";  
say "Migrating to PERL!!";  
print "Welcome to DLF!!";  
print "Migrating to PERL!!";  
 
  
 
my $x = rand(); 
#same variable or use $_
 
given ($x) {
   when ($x > 0.7) {
       say "$_ is larger than 0.7";
   }
   when ($x > 0.4) {
       say "$_ is larger than 0.4";
   }
   default {
       say "$_ is something else";
   }
}

#given ($x) {
#   when ($_ > 0.7) {
#       print "$_ is larger than 0.7";
#   }
#   when ($_ > 0.4) {
#       print "$_ is larger than 0.4";
#   }
#   default {
#       print "$_ is something else";
#   }
#}