# Double quotes
$num=5;
print "The number is $num.\n";
print "I need \$5.00.\n";
print "\t\tI can't help you.\n";